package senac.PizzaTime;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PizzaTimeApplicationTests {

	@Test
	void contextLoads() {
	}

}
