package br.senac.PizzaTime.Entities;


import jakarta.persistence.*;

import java.io.Serializable;

@Entity
public class Bebidas implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    int id;

    @Column(name = "bebida")
    String bebida;

    @Column(name = "tipo")
    String tipo;

    @Column(name = "preco")
    double preco;

    /*
    @Column(name = "img")
    String img;
    */

    public Bebidas() {}

    public Bebidas(String bebida, String tipo, double preco) {
        this.bebida = bebida;
        this.tipo = tipo;
        this.preco = preco;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getBebida() {
        return bebida;
    }

    public void setBebida(String bebida) {
        this.bebida = bebida;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }
}
