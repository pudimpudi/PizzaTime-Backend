package br.senac.PizzaTime.Configuration;

import java.text.ParseException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import br.senac.PizzaTime.Service.DBService;

@Configuration
@Profile("Teste")
public class TesteConfiguration {
    @Autowired
    DBService dbService;

    private boolean instanciarDB() throws ParseException{
        this.dbService.instanciarDB();
        return true;
    }
}
