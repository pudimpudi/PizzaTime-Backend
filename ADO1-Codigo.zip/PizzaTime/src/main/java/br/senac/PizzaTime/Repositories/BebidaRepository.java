package br.senac.PizzaTime.Repositories;

import br.senac.PizzaTime.Entities.Bebidas;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BebidaRepository extends JpaRepository<Bebidas,Integer> {
}
