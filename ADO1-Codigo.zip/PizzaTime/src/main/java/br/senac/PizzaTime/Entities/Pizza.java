package br.senac.PizzaTime.Entities;

import jakarta.persistence.*;

import java.io.Serializable;

@Entity(name="Pizza")
public class Pizza implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    int id;

    @Column(name = "sabor")
    String sabor;

    @Column(name = "preco")
    float preco;

    @Column(name = "ingredientes")
    String ingredientes;

    @Column(name = "tipo")
    String tipo;

    //@Column(name = "img")
    //String img;

    public Pizza() {}

    public Pizza(String sabor,String tipo, String ingredientes, float preco/*,String img*/) {
        this.sabor = sabor;
        this.tipo = tipo;
        this.ingredientes = ingredientes;
        this.preco = preco;
        //this.img = img;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSabor() {
        return sabor;
    }

    public void setSabor(String sabor) {
        this.sabor = sabor;
    }

    public String getIngredientes() {
        return ingredientes;
    }

    public void setIngredientes(String ingredientes) {
        this.ingredientes = ingredientes;
    }

    public float getPreco() {
        return preco;
    }

    public void setPreco(float preco) {
        this.preco = preco;
    }

    /*
    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }
    */

    public String getTipo() {
        return tipo;
    }
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}
