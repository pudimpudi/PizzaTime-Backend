package br.senac.PizzaTime.Service;

import br.senac.PizzaTime.Entities.Bebidas;
import br.senac.PizzaTime.Entities.Pizza;
import br.senac.PizzaTime.Repositories.BebidaRepository;
import br.senac.PizzaTime.Repositories.PizzaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import java.util.Arrays;

@Service
public class DBService {
    @Autowired
    private PizzaRepository pizzaRepository;

    @Autowired
    private BebidaRepository bebidaRepository;

    @Bean
    public String instanciarDB(){
        Pizza pizza1=new Pizza("Peperoni","Salgada","peperoni",40);
        Pizza pizza2=new Pizza("3 Queijos","Salgada","Mussarela,Peperoni,capupiry",40);
        Pizza pizza3=new Pizza("Portuguesa","Salgada","Presunto,ovo,mussarela,cebola",40);

        Bebidas bebida1=new Bebidas("Coca-Cola 1L","Refrigerante",12.5);
        Bebidas bebida2=new Bebidas("Coca-Cola 2L","Refrigerante",12.5);
        Bebidas bebida3=new Bebidas("Suco de Uva 1L","Suco",10.5);

        pizzaRepository.saveAll(Arrays.asList(pizza1,pizza2,pizza3));
        bebidaRepository.saveAll(Arrays.asList(bebida1,bebida2,bebida3));
        return "";
    }

}
