package br.senac.PizzaTime.Repositories;

import br.senac.PizzaTime.Entities.Pizza;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface PizzaRepository extends JpaRepository<Pizza,Integer> {

    @Query("SELECT pizza FROM Pizza pizza WHERE pizza.tipo = 'Salgada' ORDER BY pizza.sabor")
    List<Pizza> listarSalgadas();


}
