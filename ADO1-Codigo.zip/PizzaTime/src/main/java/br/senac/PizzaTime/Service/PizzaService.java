package br.senac.PizzaTime.Service;

import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.senac.PizzaTime.Entities.Pizza;
import br.senac.PizzaTime.Repositories.PizzaRepository;

@Service
public class PizzaService {
    @Autowired
    PizzaRepository pizzaRepository;

    public Pizza findById(Integer id) {
        Optional<Pizza> pizza = pizzaRepository.findById(id);
        return pizza.orElse(null);
    }

    public List<Pizza> listarSalgadas() {
        List<Pizza> pizzas = pizzaRepository.listarSalgadas();
        return pizzas;
    }

    public List<Pizza> findAll() {
        List<Pizza> pizzas = pizzaRepository.findAll();
        return pizzas;
    }

    public Pizza insert(Pizza pizza) {
        return pizzaRepository.save(pizza);
    }

    public void delete(Integer id) {
        pizzaRepository.deleteById(id);
    }

    public Pizza update(Integer id, Pizza pizza) {
        Pizza pizzaAtualizada = findById(id);
        if (pizzaAtualizada != null) {
            pizzaAtualizada.setSabor(pizza.getSabor());
            pizzaAtualizada.setIngredientes(pizza.getIngredientes());
            pizzaAtualizada.setTipo(pizza.getTipo());
            pizzaAtualizada.setPreco(pizza.getPreco());
            return pizzaRepository.save(pizzaAtualizada);
        }
        return null;
    }


}
