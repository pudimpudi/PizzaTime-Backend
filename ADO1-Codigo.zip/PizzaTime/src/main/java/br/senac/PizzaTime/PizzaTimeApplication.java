package br.senac.PizzaTime;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PizzaTimeApplication {

	public static void main(String[] args) {
		SpringApplication.run(PizzaTimeApplication.class, args);
	}

}
